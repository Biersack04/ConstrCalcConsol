package ru.sfedu.constrcaclconsol;

import org.junit.jupiter.api.Test;


class ConstrCalcClientTest {

    @Test
    public void main() {

    }
}
