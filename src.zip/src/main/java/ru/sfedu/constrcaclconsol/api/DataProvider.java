package ru.sfedu.constrcaclconsol.api;


import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import ru.sfedu.constrcaclconsol.bean.Materials;

import java.io.IOException;
import java.util.List;

public interface DataProvider {


}
