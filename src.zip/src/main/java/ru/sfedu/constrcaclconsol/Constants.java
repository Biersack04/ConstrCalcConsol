package ru.sfedu.constrcaclconsol;

public class Constants {

    static public final String WORKS_ENVIROMENT_PATH="D:\\ConstrCalcConsol\\src\\main\\resources\\works.properties";
    static public final String MATERIALS_ENVIROMENT_PATH="D:\\ConstrCalcConsol\\src\\main\\resources\\material.properties";
    static public final int WORKS_NUMBER=10;
    static public final String NAME_WORKS="work";
    static public final int MATERIALS_NUMBER=20;
    static public final String NAME_MATERIAL="material";
    static public final String SPLIT =",";
    static public final String LIST_START_SYMBOL ="[";
    static public final String LIST_END_SYMBOL ="]";
    static public final String PEOPLE_START_SYMBOL ="{";
    static public final String PEOPLE_END_SYMBOL ="}";
    public static final String CONFIG_PATH = "config.path";
    public static final String CANNOT_CREATE_FILE = "config.path";





}
