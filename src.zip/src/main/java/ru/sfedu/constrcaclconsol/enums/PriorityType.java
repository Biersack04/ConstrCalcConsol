package ru.sfedu.constrcaclconsol.enums;

public enum PriorityType {

        HIGH, MEDIUM, LOW

}
