package ru.sfedu.constrcaclconsol.enums;

public enum StatusOfCompletion {

        CREATE,
        PROCESSING,
        COMPLETED

}
